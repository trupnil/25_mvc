<html>
<head>

</head>
<body>
	<?php  include ('header.php'); ?>

<form method="POST" >
		<table align="center" border="1">
             
	
                 <tr>
					<th >Email</th>
					<td> <input type="email" name="email" placeholder="Enter Email" id="email"> </td>
				</tr>
                  <tr>
					<th >password</th>
					<td> <input type="password" name="password" placeholder="Enter password" id="email"> </td>
				</tr>
				<tr>

					<th> <input type="submit" name="login" value="Login" > </th>
				</tr>
		</table>
</form>

   </body>



</html>
