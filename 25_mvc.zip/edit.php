<html>
<head>
</head>
<body>
	<?php foreach ($edit as $res) { ?>
 		
	
<form method="POST" >
		<table align="center" border="1">
			 <tr>
				<th >reg_id</th>
				<td> <input type="text" name="reg_id" readonly value="<?php echo $res->reg_id ?>"  >
					 </td>
				</tr>

              <tr>
				<th >firstname</th>
				<td> <input type="text" name="fname" value="<?php echo $res->fname ?>" placeholder="Enter fname" id="fname">
					<span id="efname"></span> </td>
				</tr>
                 <tr>
					<th >Email</th>
					<td> <input type="email" name="email"  value="<?php echo $res->email ?>"  placeholder="Enter Email" id="email"> </td>
				</tr>
                  <tr>
					<th >password</th>
					<td> <input type="text" name="password" value="<?php echo $res->password ?>" placeholder="Enter password" id="email"> </td>
				</tr>
				<tr>
					<th> <input type="submit" name="submit" value="Update"> </th>
				</tr>
			</table>
		</form>
		
		<?php }  ?>
</body>
	</html>