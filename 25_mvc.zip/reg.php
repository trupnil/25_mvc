<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" href="js/jquery.js"></script>
</head>
<body>
<!-- 	<div style="background-color:red;">sdgvdsv</div>
	<span style="background-color:green;">sdgvdsgdsgsdg</span> -->
	<?php  include ('header.php'); ?>
<form method="POST"    enctype="multipart/form-data"    onsubmit="return validation()"  >
		<table align="center" border="1">
		

				<th >firstname </th>
	<td> <input type="text" name="fname" placeholder="Enter fname"  id="fname">
					<span id="efname"></span> </td> 
				</tr>
                 <tr>
					<th >Email</th>
					<td> <input type="email" name="email" placeholder="Enter Email"  id="email" > <span id="eemail"></span>  </td>
				</tr>
                  <tr>
					<th >password</th>
					<td> <input type="password" name="password" placeholder="Enter password" id="password" > <span id="epassword"></span>  </td>
				</tr>
				<tr>
					<th >state</th>
					<td> 
						<select name="state" id="state">
							<option> <--Please select state-->  </option>
							<?php foreach ($all_state as $res1) { ?>

							<option value="<?php echo $res1->state_id ?>"> <?php echo $res1->s_name ?> </option>
							
						<?php  	}    ?>
							
						</select>
					  </td>
				</tR>
				<tr>
					<tr>
					<th >city`</th>
					<td> 
						<select name="city" id="city">
							<option > <--Please select city-->  </option>
							<?php foreach ($all_city as $res2) { ?>
							<option value="<?php echo $res2->city_id ?>"> <?php echo $res2->city_name ?> </option>
								<?php  	}    ?>
						</select>
					</td>
				</tR>

				<tr>
					<th>Hobbies</tH>
						<td> <input type="checkbox" name="hby[]" value="php">Php
							<input type="checkbox" name="hby[]" value="python">python
							<input type="checkbox" name="hby[]" value="java">java
						 </td>
				</tr>
				<tr>

					<th>image</th>
					<td> <input type="file" name="image"> </td>
				</tr>
				<tr>
                  <th> <input type="submit" name="submit" value="reg" > </th>
				</tr>
		</table>
	</form>
</body>

<script type="text/javascript">

function validation()
{
	//alert('hi i am validation');
	var fname = document.getElementById('fname').value;
	var email = document.getElementById('email').value;
	var password = document.getElementById('password').value;
	//alert(password);

		if(fname == '')
		{
			//alert('please fill first name');
			var efname = document.getElementById('efname');
			efname.innerHTML="Please fill data First";
		    efname.style.color="red";
            return false;
		}

		if(email == '')
		{
			var eemail = document.getElementById('eemail');
			eemail.innerHTML="Please fill email First";
		    eemail.style.color="red";
			return false;
		}

		if(password == '')
		{
			var epassword = document.getElementById('epassword');
			epassword.innerHTML="Please fill data First";
		    epassword.style.color="red";
			return false;
		}



}


</script>



<script type="text/javascript">

	$(document).ready(function(){

		$('#state').change(function(){
         //alert('changed');
          var state = $('#state').val();
			//alert(state);
              $.ajax({

					url:'get_city',
					method:'POST',
					data:{state:state},
					success:function($data)
					{
						//alert($data);

						$('#city').html($data);

					}	
                });

         });
   });
</script>








</html>
