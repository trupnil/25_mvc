
<nav>
	<a href="registration">Registration</a>
	<a href="login">Login</a>
	<a href="showdata">ShowData</a>
	<a href="Addcategory">AddCategory</a>
	<a href="Addproduct">AddProduct</a>
</nav>