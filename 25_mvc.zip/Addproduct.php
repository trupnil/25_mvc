<html>
<head>

</head>
<body>
<?php include('header.php');?><br>

<form method="POST" enctype="multipart/form-data" >
		<table align="center" border="1">
             
	
                 <tr>
					<th >Select Category</th>
					<td> 

						<select name="category">
							<option> <-- select category first --> </option>
							<?php foreach ($cat as $key => $value) { ?>
								<option value="<?php echo $value->cat_id; ?>">
								 <?php  echo $value->cat_name; ?> </option>
						<?php  	}  ?>
						  </select>


					   </td>
				</tr>
				<tr>
					<th>Add Product Name</tH>
					<td>	<input type="text" name="p_name" placeholder="Enter product name">
					 </td>
				</tr>
				<tr>
					<th>Add Product Price</tH>
					<td>	<input type="text" name="p_price" placeholder="Enter product name">
					</td>
				</tr>
				
				<tr>
					<th>Add Product image</tH>
					<td>	<input type="file" name="p_image" placeholder="Enter product name">
					</td>
				</tr>

				<tr>
					<th>Add Product Details</tH>
						<td><textarea name="p_details" rows="10" cols="50">

						</textarea></td>
						</tr>
                 

					<th> <input type="submit" name="submit" value="Add Product" > </th>
				</tr>
		</table>
</form>

   </body>



</html>
