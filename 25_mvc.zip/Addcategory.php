<html>
<head>

</head>
<body>
<?php include('header.php');?>
<br>
<form method="POST" >
		<table align="center" border="1">
             
	
                 <tr>
					<th >Add Category</th>
					<td> <input type="text" name="cat_name" placeholder="Enter category" > </td>
				</tr>
				<th> <input type="submit" name="submit" value="Add category" > </th>
				</tr>
		</table>
</form>

   </body>



</html>
