<?php
Class Model
{
	public $db;
	public function __construct()
	{	
		$this->db = new mysqli("localhost","root","","25_mvc");
		// if($this->db)
		// {
		// 	echo "database connected";
		// } 
		// else
		// {
		// 	echo "Error";
		// }

	}

	public function insert($table,$data)
	{
		//echo $table;

		$keys = implode('`,`',array_keys($data));

		$values = implode("','",array_values($data));
		
		$sql = "INSERT INTO `$table` (`$keys`) VALUES ('$values')"; 

		return $ex = $this->db->query($sql);


	}

	public function select_all($table)
	{

		$sql = "SELECT * FROM `$table`";
		$ex = $this->db->query($sql);

		
			while($res = mysqli_fetch_object($ex))
		{
           $r[] = $res;
		}

		
		
		return $r;

	}

	public function delete($table,$where)
	{
		$condition="";//data member
		foreach ($where as $key => $value) {
			//echo $value;
          $condition = $condition."`$key` = '$value' ";
		}
		
		//echo $condition;

		$sql = "DELETE FROM `$table` WHERE $condition";
		return $ex = $this->db->query($sql);

	}	

	public function select_where($table,$where)
	{
		$condition="";
		foreach ($where as $key => $value) {
			
			$condition = $condition."`$key` = '$value'";
		}
		//echo $condition;
		$sql = "SELECT * FROM `$table` WHERE $condition";
		
			$ex = $this->db->query($sql);
		while($res = mysqli_fetch_object($ex))
		{
           $r[] = $res;
		}
		return $r;


	}

	public function update($table,$data,$where)
	{
		$condition="";
		foreach ($where as $key => $value) {
			
			$condition = $condition."`$key` = '$value'";
		}

		$update = "";
		foreach ($data as $key => $value) {
			
			$update = $update."`$key` = '$value' ,";
		}

		$update = rtrim($update,",");

		$sql = "UPDATE `$table` SET $update WHERE $condition";
		return $ex = $this->db->query($sql);


	}

	public  function login($table,$where)
	{
		$condition="";
		foreach ($where as $key => $value) {
			
			$condition = $condition."`$key` = '$value' AND";
		}

		$condition = rtrim($condition,"AND");



		 $sql ="SELECT * FROM `$table` WHERE $condition";
		 $ex = $this->db->query($sql);
		 
		 while($res = mysqli_fetch_object($ex))
		{
           $r[] = $res;
		}
		return $r;

	}









	public function join_three($table1,$table2,$table3,$con1,$con2)
	{
		$sql = "SELECT * FROM `$table1` INNER JOIN `$table2` ON $con1 INNER JOIN `$table3` ON $con2";
		 $ex = $this->db->query($sql);
		 
		 
		if($ex->num_rows > 0)
		{
			while($res = mysqli_fetch_object($ex))
		{
           $r[] = $res;
		}

		}

		else
		{
			$r[] = "No record found";
		}
		
		return $r;
	} 


public function join_two($table1,$table2,$con1)
	{
		$sql = "SELECT * FROM `$table1` INNER JOIN `$table2` ON $con1";
		 $ex = $this->db->query($sql);
		 
		 
		if($ex->num_rows > 0)
		{
			while($res = mysqli_fetch_object($ex))
		{
           $r[] = $res;
		}

		}

		else
		{
			$r[] = "No record found";
		}
		
		return $r;
	}






}


?>