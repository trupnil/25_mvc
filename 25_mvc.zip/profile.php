<?php 
session_start();
// echo $_SESSION['userdata']->fname;

 ?>
 <table border="2" align="center" cellspacing="10" cellpadding="10" style="background:#d9fdff;">
	
	<tr >
		<tr>
			<th><?php echo $_SESSION['userdata']->fname?></th>
			<th> <a href="logout">logout</a> </tH>
		</tr>
		
		<th>id</th>
		<tH> fname </tH>
		<th> email </tH>
		<th> password </tH>
       
			   </tr>

			   

			   		<tr>
			   			<td>  <?php echo $_SESSION['userdata']->reg_id;  ?> </td>
			   			<td>  <?php echo $_SESSION['userdata']->fname; ?> </td>
			   			<td>  <?php echo $_SESSION['userdata']->email; ?> </td>
			   			<td>  <?php echo $_SESSION['userdata']->password; ?> </td>
			   				</tr>
			   		
			   		
			   


			

							</table> 