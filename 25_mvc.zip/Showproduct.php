
<html>
<head>
</head>
<body>
	<?php include('header.php');?>
	<br>
<table border="2" align="center" cellspacing="10" cellpadding="10" style="background:#d9fdff;">
	
	<tr >
	
          <th>id</th>
		<th>image</tH>
		<th> product category </tH>
		
		<tH> product Name </tH>
		<th> product price </tH>
			<th> product Details </tH>
		</tr>

			   	<?php 
			   	 
			   	foreach ($all_product as $result) 
			   	{
			   		?>

			   		<tr>
			   			<td>  <?php echo $result->p_id ?> </td>
			   				<td>  <img src="product/<?php echo $result->p_image ?>" height="100px" width="100px"> </td>
			   		       <td>  <?php echo $result->cat_name ?> </td>
			   			<td>  <?php echo $result->p_name ?> </td>
			   			<td>  <?php echo $result->p_price ?> </td>
			   			<td> <?php echo $result->p_details ?></td>
			   			</tr>
			   		
			   		
			   	<?php  }    ?>

			   

			

							</table>
							</form>
						</body>
						</html>