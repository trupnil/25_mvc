
<html>
<head>
</head>
<body>
	<form method="POST">
<table border="2" align="center" cellspacing="10" cellpadding="10" style="background:#d9fdff;">
	
	<tr >
		<th>image</tH>
		<th>#</th>
		<th>id</th>
		<tH> fname </tH>
		<th> email </tH>
		<th> password </tH>
			<th>state</th>
			<th>city</tH>
				<th>Hobbies</th>
        <th colspan="2" > Action </th>
			   </tr>

			   	<?php 
			   	//print_r($data);
			   		if(($data[0] == 'No record found'))
			   		{

			   			echo "no record found";
			   			}
			   			else
			   			{






			   	foreach ($data as $result) 
			   	{
			   		?>

			   		<tr>
			   			<td>  <img src="upload/<?php echo $result->image ?>" height="100px" width="100px"> </td>
			   			<td> <input type="checkbox" name="chk[]" value="<?php echo $result->reg_id;  ?>"> </td>
			   			<td>  <?php echo $result->reg_id ?> </td>
			   			<td>  <?php echo $result->fname ?> </td>
			   			<td>  <?php echo $result->email ?> </td>
			   			<td>  <?php echo $result->password ?> </td>
			   			<td> <?php echo $result->s_name ?></td>
			   			<td> <?php echo $result->city_name ?></td>
			   			<td> <?php echo $result->hobbies ?></td>
			   			<td> <a href ="delete?id=<?php echo $result->reg_id; ?>">Delete</a> </td>
			   			<td> <a href ="edit?id=<?php echo $result->reg_id; ?>">Edit</a> </td>
			   		</tr>
			   		
			   		
			   	<?php  }  }  ?>

			   	<tr>
			   		<th> <input type="submit" name="mult_del" value="Delete_all" >  </tH>
			   	</tR>

			

							</table>
							</form>
						</body>
						</html>