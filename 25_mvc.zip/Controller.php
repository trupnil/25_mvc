<?php
include ('Model.php');

Class Controller extends Model
{
	public function __construct()
	{
		parent::__construct();

		//print_r($_SERVER['PATH_INFO']);

		if($_SERVER['PATH_INFO'] == '/get_city')
		{
			$state = $_POST['state'];
			$where = array("state"=>$state);
			$city =  $this->select_where("city",$where);
            
            foreach ($city as $mini) {

            	echo "<option value='$mini->city_id'> $mini->city_name </option>";


            	
            }

			//echo $state;
		}
			if($_SERVER['PATH_INFO'] == '/logout')
			{
				session_start();
				session_destroy();
				header("location:login");

			}

			if($_SERVER['PATH_INFO'] == '/profile')
			{
				include('profile.php');

			}
		 
		if($_SERVER['PATH_INFO'] == '/registration')
		{
			$all_state = $this->select_all("state");
			$all_city = $this->select_all("city");

			if(isset($_POST['submit']))
			{
				$fname = $_POST['fname'];
				$email = $_POST['email'];
				$password = $_POST['password'];
				$state = $_POST['state'];
				$city = $_POST['city'];
				$hobbies = $_POST['hby'];
				$hby = implode(',',$hobbies);

				$image_name =  $_FILES['image']['name'];


				$image_type =  $_FILES['image']['type'];

			

				$image_size =  $_FILES['image']['size'];
				$tmp_name =  $_FILES['image']['tmp_name'];
				$new_path = ("upload/".$image_name);
				move_uploaded_file($tmp_name,$new_path);

				$data = array("fname" =>$fname,"email" => $email, "password"=>$password,"state"=>$state,"city"=>$city,"hobbies"=>$hby,"image"=>$image_name );

				//print_r($data);

				$ins =  $this->insert("reg",$data);

				if($ins)
				{
					echo "inserted";
				}
				else
				{
					echo "Error";
				}

			}


			include('reg.php');
		}


		if($_SERVER['PATH_INFO'] == '/showdata')
		{
			//$data =  $this->select_all("reg");

			$data = $this->join_three("reg","state","city","`reg`.`state` = `state`.`state_id`","`reg`.`city` = `city`.`city_id`");
			//print_r($data);
			include('Showdata.php');

			if(isset($_POST['mult_del']))
			{
				$chk = $_POST['chk'];
				//print_r($chk);
				$x = count($chk);
				//echo $x;
				for ($i=0; $i < $x ; $i++) { 

					$where = array("reg_id"=>$chk[$i]);
					//print_r($where);
					$del =  $this->delete("reg",$where);


					
				}
				if($del)
			{
				echo "Deleted";
				header('refresh:1;showdata');
			}
			else
			{
				echo "Error";
			}


			}

		}


		if($_SERVER['PATH_INFO'] == '/delete')
		{
			$reg_id = $_GET['id'];
			//echo $reg_id;
			$where = array("reg_id"=>$reg_id);
			//print_r($where);
			$del =  $this->delete("reg",$where);

			if($del)
			{
				echo "Deleted";
				header('location:showdata');
			}
			else
			{
				echo "Error";
			}
		}

		if(($_SERVER['PATH_INFO'] == '/login'))
		{
			if(isset($_POST['login']))
			{
				$email = $_POST['email'];
				$password = $_POST['password'];

				$where = array("email"=>$email,"password" => $password);

				$login = $this->login("reg",$where);
				//echo "<pre>";
				//print_r($login);
				//echo ($login);
				
				if(count($login) == 1 )
				{
					echo "oke";
					session_start();
					$_SESSION['userdata'] = $login[0];
					header('location:profile');
				}
				else
				{
					echo "check email and password";
				}					

			}
			include ('login.php');
		}


		
		if($_SERVER['PATH_INFO'] == '/edit')
         {
         	$reg_id = $_GET['id'];
         	$where = array("reg_id"=>$reg_id);
			$edit =  $this->select_where("reg",$where);  

			if(isset($_POST['submit']))
			{
				$reg_id = $_POST['reg_id'];
				$fname = $_POST['fname'];
				$email = $_POST['email'];
				$password = $_POST['password'];
				$data = array("fname"=>$fname,"email"=>$email,"password"=>$password);
				$where = array("reg_id"=>$reg_id);

				$update = $this->update("reg",$data,$where);
				if($update)
				{
					header('location:showdata');
				}
				else
				{
					echo "Error";
				}
               }
             include('edit.php');
            }

            if($_SERVER['PATH_INFO'] == '/addcategory')

            {
            	if(isset($_POST['submit']))
            	{

            		$cat_name = $_POST['cat_name'];

            		$data = array("cat_name"=>$cat_name);

            		$cat =  $this->insert("category",$data);

            		if($cat)
            		{
            			echo "Category succesfully added!!";

            		}
            		else
            		{
            			echo "Error";
            		}

            	}

            	include('Addcategory.php');

            }

             if($_SERVER['PATH_INFO'] == '/Addproduct')

            {
            	$cat = $this->select_all('category');
            	//print_r($cat);
            	if(isset($_POST['submit']))
            	{

            		$category = $_POST['category'];
            		$p_name = $_POST['p_name'];
            		$p_price = $_POST['p_price'];
            		$p_details = $_POST['p_details'];

            		$image_name = $_FILES['p_image']['name'];
            		$image_type = $_FILES['p_image']['type'];
            		$image_size = $_FILES['p_image']['size'];
            		$tmp_name = $_FILES['p_image']['tmp_name'];
            		$new_path = ("product/".$image_name);
            		move_uploaded_file($tmp_name,$new_path);

            		$data = array(
            			"category"=>$category,
            			"p_name" => $p_name,
            			"p_price" => $p_price,
            			"p_details" => $p_details,
            			"p_image" => $image_name
                          );

            		$ins = $this->insert("product",$data);

            		if($ins)
            		{
            			//echo "Added succesfully";
            			header('location:Showproduct');
            		}
            		else
            		{
            			echo "Error";
            		}




            	}


                include('Addproduct.php');

            }

            if($_SERVER['PATH_INFO'] == '/Showproduct')
            {

            	//$all_product = $this->select_all('product');
            	$all_product = $this->join_two('product','category',"`product`.`category` = `category`.`cat_id`");
            	include('Showproduct.php');

            }



            if ($_SERVER['PATH_INFO'] == '/Userproduct') {

            	$product =  $this->select_all("product");
            	//print_r($product);
            	include('Userproduct.php');
            	
            }


             if ($_SERVER['PATH_INFO'] == '/Productdetails') {

             	session_start();
            	
            	//print_r($product);
            	if(isset($_GET['p_id']))
            	{
            		$p_id = $_GET['p_id'];
            		//echo $p_id;
            		$where = array("p_id"=>$p_id);
            		$p_details =  $this->select_where("product",$where);

            		//print_r($p_details);



            		include('Productdetails.php');

            	}
            	
            	
            }

            if($_SERVER['PATH_INFO'] == '/cart')
            {

            	$user_id = $_POST['user_id'];
            	$product_id = $_POST['product_id'];

            	//echo $product_id;
          	$data = array("user_id" => $user_id,"product_id" => $product_id);

          	$cart =  $this->insert("cart",$data);

          	if($cart)
          	{
          		header("location:Showcart");
          	}
          	else
          	{
          		echo "Error";
          	}

           

            }

            if($_SERVER['PATH_INFO'] == '/Showcart')
            {

            	include('Showcart.php');
           

            }





        









	}
}

$obj = new Controller;

?>